package com.gamecast.screenrecorder.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.gamecast.screenrecorder.R
import com.gamecast.screenrecorder.model.RecordedVideo
import com.gamecast.screenrecorder.model.RecorderStateBus
import java.util.Locale

class RecordingsAdapter(
    private val onClick: (RecordedVideo) -> Unit,
    private val onTrimClick: (RecordedVideo) -> Unit
) : ListAdapter<RecordedVideo, RecordingsAdapter.VideoViewHolder>(DiffCallback) {

    object DiffCallback : DiffUtil.ItemCallback<RecordedVideo>() {
        override fun areItemsTheSame(oldItem: RecordedVideo, newItem: RecordedVideo): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: RecordedVideo, newItem: RecordedVideo): Boolean =
            oldItem == newItem
    }

    inner class VideoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tvVideoName)
        private val tvMeta: TextView = itemView.findViewById(R.id.tvVideoMeta)
        private val btnTrim: Button = itemView.findViewById(R.id.btnTrimVideo)

        fun bind(video: RecordedVideo) {
            tvName.text = video.displayName
            val duration = RecorderStateBus.formatDuration(video.durationMs / 1000L)
            val sizeMb = String.format(Locale.US, "%.1f MB", video.sizeBytes / (1024.0 * 1024.0))
            tvMeta.text = "$duration · $sizeMb"
            itemView.setOnClickListener { onClick(video) }
            btnTrim.setOnClickListener { onTrimClick(video) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recorded_video, parent, false)
        return VideoViewHolder(view)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}
