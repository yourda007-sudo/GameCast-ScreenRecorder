package com.gamecast.screenrecorder.media

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Lossless keyframe-aligned MP4 trimmer powered by MediaExtractor + MediaMuxer.
 */
object VideoTrimmer {

    suspend fun trimVideo(
        context: Context,
        sourceUri: Uri,
        startMs: Long,
        endMs: Long,
        speed: Float = 1.0f
    ): Pair<Uri, String> = withContext(Dispatchers.IO) {
        val safeSpeed = speed.coerceIn(0.25f, 4.0f)
        val extractor = MediaExtractor()
        extractor.setDataSource(context, sourceUri, null)

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val speedTag = when {
            safeSpeed < 0.99f -> "SlowMo_${safeSpeed}x_"
            safeSpeed > 1.01f -> "Fast_${safeSpeed}x_"
            else -> "Trim_"
        }
        val outName = "GameCast_${speedTag}$timestamp.mp4"

        val tempOutFile = File(context.cacheDir, outName)
        val muxer = MediaMuxer(tempOutFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val trackIndexMap = HashMap<Int, Int>()
        var maxBufferSize = 1024 * 1024

        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            val includeTrack = mime.startsWith("video/") ||
                (safeSpeed == 1.0f && mime.startsWith("audio/"))
            if (includeTrack) {
                extractor.selectTrack(i)
                val dstIndex = muxer.addTrack(format)
                trackIndexMap[i] = dstIndex
                if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    maxBufferSize = maxOf(
                        maxBufferSize,
                        format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                    )
                }
            }
        }

        val startUs = startMs * 1000L
        val endUs = endMs * 1000L
        extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

        val buffer = ByteBuffer.allocate(maxBufferSize)
        val bufferInfo = MediaCodec.BufferInfo()

        muxer.start()
        try {
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = extractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) {
                    bufferInfo.size = 0
                    break
                }
                val sampleTimeUs = extractor.sampleTime
                if (endUs > 0 && sampleTimeUs > endUs) {
                    break
                }
                val trackIndex = extractor.sampleTrackIndex
                val dstTrack = trackIndexMap[trackIndex]
                if (dstTrack != null && sampleTimeUs >= startUs) {
                    val shiftedUs = sampleTimeUs - startUs
                    bufferInfo.presentationTimeUs = (shiftedUs / safeSpeed).toLong()
                    bufferInfo.flags = extractor.sampleFlags
                    muxer.writeSampleData(dstTrack, buffer, bufferInfo)
                }
                extractor.advance()
            }
        } finally {
            muxer.stop()
            muxer.release()
            extractor.release()
        }

        val finalUri = saveTrimmedToMediaStore(context, tempOutFile, outName)
        tempOutFile.delete()
        finalUri to outName
    }

    private fun saveTrimmedToMediaStore(
        context: Context,
        sourceFile: File,
        fileName: String
    ): Uri {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_MOVIES}/GameCast Recorder"
                )
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Unable to insert trimmed MP4 in MediaStore")
            resolver.openOutputStream(uri)?.use { out ->
                sourceFile.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "GameCast Recorder"
            ).apply { mkdirs() }
            val dest = File(dir, fileName)
            sourceFile.copyTo(dest, overwrite = true)
            Uri.fromFile(dest)
        }
    }
}
