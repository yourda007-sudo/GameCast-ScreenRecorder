package com.gamecast.screenrecorder.service

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.gamecast.screenrecorder.R
import com.gamecast.screenrecorder.model.AudioSourceMode
import com.gamecast.screenrecorder.model.RecorderStateBus
import com.gamecast.screenrecorder.model.RecordingConfig
import com.gamecast.screenrecorder.model.RecordingState
import com.gamecast.screenrecorder.ui.MainActivity
import com.gamecast.screenrecorder.ui.ProjectionPromptActivity
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingControlService : Service() {

    companion object {
        const val ACTION_SHOW = "com.gamecast.screenrecorder.overlay.SHOW"
        const val ACTION_HIDE = "com.gamecast.screenrecorder.overlay.HIDE"

        private const val CHANNEL_ID = "gamecast_overlay_channel"
        private const val NOTIFICATION_ID = 1001

        fun show(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            try {
                val intent = Intent(context, FloatingControlService::class.java).apply {
                    action = ACTION_SHOW
                }
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Throwable) {
            }
        }

        fun hide(context: Context) {
            try {
                context.stopService(Intent(context, FloatingControlService::class.java))
            } catch (_: Throwable) {
            }
        }
    }

    private val exceptionHandler = CoroutineExceptionHandler { _, _ -> }
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main + exceptionHandler)
    private lateinit var windowManager: WindowManager
    private lateinit var layoutParams: WindowManager.LayoutParams
    private var floatingView: View? = null

    private var isExpanded = true
    private var isIslandExpanded = false
    private var inDynamicIslandMode = false
    private var savedFloatX = 0
    private var savedFloatY = 0
    private var edgeSnapAnimator: ValueAnimator? = null
    private var dotPulseAnimator: ObjectAnimator? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> {
                startOverlayForeground()
                stopSelf()
                return START_NOT_STICKY
            }

            else -> {
                startOverlayForeground()
                if (!Settings.canDrawOverlays(this)) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                attachFloatingWindowIfNeeded()
            }
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val view = floatingView ?: return
        if (inDynamicIslandMode) {
            applyDynamicIslandGeometry(
                view,
                newConfig.orientation,
                RecorderStateBus.config.value
            )
        }
    }

    private fun startOverlayForeground() {
        try {
            val notification = buildOverlayNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Throwable) {
        }
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun attachFloatingWindowIfNeeded() {
        if (floatingView != null) return

        val view = LayoutInflater.from(this).inflate(R.layout.layout_floating_widget, null)
        floatingView = view

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        savedFloatX = dpToPx(16)
        savedFloatY = dpToPx(160)

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedFloatX
            y = savedFloatY
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        bindWidgetControls(view)
        setupDragAndDrop(view)
        observeRecorderState(view)

        try {
            windowManager.addView(view, layoutParams)
            RecorderStateBus.setOverlayVisible(true)
        } catch (_: Throwable) {
            floatingView = null
            RecorderStateBus.setOverlayVisible(false)
            stopSelf()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun bindWidgetControls(root: View) {
        val collapsedBubble = root.findViewById<View>(R.id.collapsedBubble)
        val expandedPanel = root.findViewById<LinearLayout>(R.id.expandedPanel)
        val btnPrimary = root.findViewById<ImageButton>(R.id.btnPrimaryAction)
        val btnStop = root.findViewById<ImageButton>(R.id.btnStop)
        val btnCollapse = root.findViewById<ImageButton>(R.id.btnCollapse)
        val btnClose = root.findViewById<ImageButton>(R.id.btnCloseOverlay)

        // iPhone Dynamic Island controls
        val islandCompact = root.findViewById<View>(R.id.dynamicIslandCompact)
        val islandExpanded = root.findViewById<View>(R.id.dynamicIslandExpanded)
        val btnIslandPauseResume = root.findViewById<ImageButton>(R.id.btnIslandPauseResume)
        val btnIslandMicToggle = root.findViewById<ImageButton>(R.id.btnIslandMicToggle)
        val btnIslandScreenshot = root.findViewById<ImageButton>(R.id.btnIslandScreenshot)
        val btnIslandStop = root.findViewById<ImageButton>(R.id.btnIslandStop)
        val btnIslandCollapse = root.findViewById<ImageButton>(R.id.btnIslandCollapse)

        fun applyExpansionState() {
            collapsedBubble.visibility = if (isExpanded) View.GONE else View.VISIBLE
            expandedPanel.visibility = if (isExpanded) View.VISIBLE else View.GONE
        }
        applyExpansionState()

        btnCollapse.setOnClickListener {
            isExpanded = false
            applyExpansionState()
            if (RecorderStateBus.config.value.edgeSnapEnabled) {
                snapToNearestEdge()
            }
        }

        btnPrimary.setOnClickListener {
            when (RecorderStateBus.state.value) {
                RecordingState.IDLE -> {
                    val promptIntent = Intent(this, ProjectionPromptActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    }
                    startActivity(promptIntent)
                }

                RecordingState.RECORDING -> {
                    ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_PAUSE)
                }

                RecordingState.PAUSED -> {
                    ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_RESUME)
                }
            }
        }

        btnStop.setOnClickListener {
            if (RecorderStateBus.state.value != RecordingState.IDLE) {
                ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_STOP)
            }
        }

        btnClose.setOnClickListener {
            if (RecorderStateBus.state.value != RecordingState.IDLE) {
                ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_STOP)
            }
            stopSelf()
        }

        // Dynamic Island gesture handler: Single Tap or Double Tap to Expand + Drag when unlocked
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        val gestureDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    if (!RecorderStateBus.config.value.doubleTapToExpand) {
                        isIslandExpanded = true
                        islandCompact.visibility = View.GONE
                        islandExpanded.visibility = View.VISIBLE
                    }
                    return true
                }

                override fun onDoubleTap(e: MotionEvent): Boolean {
                    if (RecorderStateBus.config.value.doubleTapToExpand) {
                        isIslandExpanded = true
                        islandCompact.visibility = View.GONE
                        islandExpanded.visibility = View.VISIBLE
                    }
                    return true
                }
            }
        )

        islandCompact.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchStartX = 0f
            private var touchStartY = 0f
            private var dragged = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                gestureDetector.onTouchEvent(event)
                val cfg = RecorderStateBus.config.value
                if (cfg.islandPositionLocked) return true

                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = layoutParams.x
                        startY = layoutParams.y
                        touchStartX = event.rawX
                        touchStartY = event.rawY
                        dragged = false
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchStartX).toInt()
                        val dy = (event.rawY - touchStartY).toInt()
                        if (!dragged && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                            dragged = true
                        }
                        if (dragged) {
                            layoutParams.x = startX + dx
                            layoutParams.y = startY + dy
                            safeUpdateViewLayout(root)
                        }
                    }

                    MotionEvent.ACTION_UP -> {
                        if (dragged) {
                            val newOffsetX = ((layoutParams.x) / resources.displayMetrics.density).toInt()
                            val newOffsetY = ((layoutParams.y) / resources.displayMetrics.density).toInt()
                            RecorderStateBus.updateConfig(
                                cfg.copy(
                                    islandOffsetX = newOffsetX.coerceIn(-100, 100),
                                    islandOffsetY = newOffsetY.coerceIn(-40, 120)
                                )
                            )
                        }
                    }
                }
                return true
            }
        })

        btnIslandCollapse.setOnClickListener {
            isIslandExpanded = false
            islandExpanded.visibility = View.GONE
            islandCompact.visibility = View.VISIBLE
        }

        btnIslandPauseResume.setOnClickListener {
            when (RecorderStateBus.state.value) {
                RecordingState.RECORDING ->
                    ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_PAUSE)

                RecordingState.PAUSED ->
                    ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_RESUME)

                RecordingState.IDLE -> Unit
            }
        }

        btnIslandMicToggle.setOnClickListener {
            ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_TOGGLE_MIC)
        }

        btnIslandScreenshot.setOnClickListener {
            ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_SCREENSHOT)
        }

        btnIslandStop.setOnClickListener {
            ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_STOP)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragAndDrop(root: View) {
        val dragHandle = root.findViewById<View>(R.id.dragHandle)
        val collapsedBubble = root.findViewById<View>(R.id.collapsedBubble)
        val expandedPanel = root.findViewById<LinearLayout>(R.id.expandedPanel)
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDragging = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        edgeSnapAnimator?.cancel()
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY

                        if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                            isDragging = true
                        }

                        if (isDragging) {
                            val (screenW, screenH) = getScreenBounds()
                            val viewW = root.width.coerceAtLeast(dpToPx(56))
                            val viewH = root.height.coerceAtLeast(dpToPx(56))

                            layoutParams.x = (initialX + dx.toInt()).coerceIn(0, screenW - viewW)
                            layoutParams.y = (initialY + dy.toInt()).coerceIn(dpToPx(24), screenH - viewH)
                            savedFloatX = layoutParams.x
                            savedFloatY = layoutParams.y
                            safeUpdateViewLayout(root)
                        }
                        return true
                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (!isDragging && v.id == R.id.collapsedBubble) {
                            isExpanded = true
                            collapsedBubble.visibility = View.GONE
                            expandedPanel.visibility = View.VISIBLE
                            clampInsideScreen(root)
                        } else if (isDragging && RecorderStateBus.config.value.edgeSnapEnabled) {
                            snapToNearestEdge()
                        }
                        return true
                    }
                }
                return false
            }
        }

        dragHandle.setOnTouchListener(dragListener)
        collapsedBubble.setOnTouchListener(dragListener)
    }

    private fun switchToDynamicIslandPosition(root: View, active: Boolean) {
        if (inDynamicIslandMode == active) return
        inDynamicIslandMode = active

        if (active) {
            savedFloatX = layoutParams.x
            savedFloatY = layoutParams.y
            isIslandExpanded = false
            applyDynamicIslandGeometry(
                root,
                resources.configuration.orientation,
                RecorderStateBus.config.value
            )
        } else {
            dotPulseAnimator?.cancel()
            layoutParams.gravity = Gravity.TOP or Gravity.START
            layoutParams.x = savedFloatX
            layoutParams.y = savedFloatY
            safeUpdateViewLayout(root)
        }
    }

    private fun applyDynamicIslandGeometry(
        root: View,
        orientation: Int,
        config: RecordingConfig
    ) {
        val compact = root.findViewById<LinearLayout>(R.id.dynamicIslandCompact)
        val dotView = root.findViewById<ImageView>(R.id.ivIslandRecordRing)
        val safeScale = config.islandScale.coerceIn(0.70f, 1.45f)
        val safeDotScale = config.dotScale.coerceIn(0.60f, 1.60f)

        val longEdgePx = dpToPx((140 * safeScale).toInt())
        val shortEdgePx = dpToPx((37 * safeScale).toInt())
        val dotSizePx = dpToPx((12 * safeScale * safeDotScale).toInt().coerceAtLeast(6))
        val dotOffsetPx = dpToPx((18 * safeScale).toInt()).toFloat()

        // Apply custom corner radius & opacity
        compact.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.BLACK)
            cornerRadius = dpToPx(config.islandCornerRadiusDp).toFloat()
        }
        compact.alpha = config.islandOpacity.coerceIn(0.55f, 1.0f)

        val lp = compact.layoutParams
        val dotLp = dotView.layoutParams
        dotLp.width = dotSizePx
        dotLp.height = dotSizePx
        dotView.layoutParams = dotLp

        val offsetX = dpToPx(config.islandOffsetX)
        val offsetY = dpToPx(config.islandOffsetY)

        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            lp.width = shortEdgePx
            lp.height = longEdgePx
            compact.orientation = LinearLayout.VERTICAL
            dotView.translationX = 0f
            dotView.translationY = -dotOffsetPx
            layoutParams.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            layoutParams.x = (dpToPx(12) + offsetX).coerceAtLeast(0)
            layoutParams.y = offsetY
        } else {
            lp.width = longEdgePx
            lp.height = shortEdgePx
            compact.orientation = LinearLayout.HORIZONTAL
            dotView.translationX = dotOffsetPx
            dotView.translationY = 0f
            layoutParams.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutParams.x = offsetX
            layoutParams.y = (dpToPx(8) + offsetY).coerceAtLeast(0)
        }
        compact.layoutParams = lp
        safeUpdateViewLayout(root)
    }

    private fun safeUpdateViewLayout(view: View) {
        if (!view.isAttachedToWindow) return
        try {
            windowManager.updateViewLayout(view, layoutParams)
        } catch (_: Throwable) {
        }
    }

    private fun updateDotPulseAnimation(dotView: View, shouldPulse: Boolean) {
        if (shouldPulse) {
            if (dotPulseAnimator?.isRunning == true) return
            dotPulseAnimator = ObjectAnimator.ofFloat(dotView, View.ALPHA, 1.0f, 0.35f).apply {
                duration = 750L
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                start()
            }
        } else {
            dotPulseAnimator?.cancel()
            dotPulseAnimator = null
            dotView.alpha = 1.0f
        }
    }

    private fun createIndicatorDotDrawable(hexColor: String): LayerDrawable {
        val baseColor = try {
            Color.parseColor(hexColor)
        } catch (_: IllegalArgumentException) {
            Color.parseColor("#F97316")
        }
        val haloColor = Color.argb(
            85,
            Color.red(baseColor),
            Color.green(baseColor),
            Color.blue(baseColor)
        )
        val halo = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(haloColor)
        }
        val core = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(baseColor)
        }
        val inset = dpToPx(2)
        return LayerDrawable(arrayOf(halo, core)).apply {
            setLayerInset(1, inset, inset, inset, inset)
        }
    }

    private fun snapToNearestEdge() {
        val view = floatingView ?: return
        val (screenW, _) = getScreenBounds()
        val viewW = view.width.coerceAtLeast(dpToPx(56))
        val margin = dpToPx(12)
        val centerX = layoutParams.x + viewW / 2
        val targetX = if (centerX < screenW / 2) {
            margin
        } else {
            (screenW - viewW - margin).coerceAtLeast(margin)
        }

        edgeSnapAnimator?.cancel()
        edgeSnapAnimator = ValueAnimator.ofInt(layoutParams.x, targetX).apply {
            duration = 180L
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                val activeView = floatingView ?: return@addUpdateListener
                layoutParams.x = anim.animatedValue as Int
                savedFloatX = layoutParams.x
                safeUpdateViewLayout(activeView)
            }
            start()
        }
    }

    private fun clampInsideScreen(root: View) {
        root.post {
            val (screenW, screenH) = getScreenBounds()
            val maxX = (screenW - root.width - dpToPx(12)).coerceAtLeast(0)
            val maxY = (screenH - root.height - dpToPx(24)).coerceAtLeast(dpToPx(24))
            layoutParams.x = layoutParams.x.coerceIn(dpToPx(12), maxX)
            layoutParams.y = layoutParams.y.coerceIn(dpToPx(24), maxY)
            safeUpdateViewLayout(root)
        }
    }

    private fun observeRecorderState(root: View) {
        val collapsedBubble = root.findViewById<View>(R.id.collapsedBubble)
        val expandedPanel = root.findViewById<LinearLayout>(R.id.expandedPanel)
        val dynamicIslandContainer = root.findViewById<View>(R.id.dynamicIslandContainer)
        val islandCompact = root.findViewById<View>(R.id.dynamicIslandCompact)
        val islandExpanded = root.findViewById<View>(R.id.dynamicIslandExpanded)
        val ivIslandRecordRing = root.findViewById<ImageView>(R.id.ivIslandRecordRing)
        val ivIslandCompactMicOff = root.findViewById<ImageView>(R.id.ivIslandCompactMicOff)
        val ivIslandExpandedRing = root.findViewById<ImageView>(R.id.ivIslandExpandedRing)

        val statusDot = root.findViewById<View>(R.id.statusDot)
        val bubbleDot = root.findViewById<View>(R.id.bubbleIndicatorDot)
        val tvTimer = root.findViewById<TextView>(R.id.tvFloatingTimer)
        val btnPrimary = root.findViewById<ImageButton>(R.id.btnPrimaryAction)
        val btnStop = root.findViewById<ImageButton>(R.id.btnStop)

        val tvIslandExpandedTimer = root.findViewById<TextView>(R.id.tvIslandExpandedTimer)
        val tvIslandStatusLabel = root.findViewById<TextView>(R.id.tvIslandStatusLabel)
        val btnIslandPauseResume = root.findViewById<ImageButton>(R.id.btnIslandPauseResume)
        val btnIslandMicToggle = root.findViewById<ImageButton>(R.id.btnIslandMicToggle)

        serviceScope.launch {
            combine(
                RecorderStateBus.state,
                RecorderStateBus.elapsedSeconds,
                RecorderStateBus.config,
                RecorderStateBus.micMuted
            ) { state, seconds, config, micMuted ->
                arrayOf<Any>(state, seconds, config, micMuted)
            }.collect { values ->
                val state = values[0] as RecordingState
                val seconds = values[1] as Long
                val config = values[2] as RecordingConfig
                val micMuted = values[3] as Boolean

                try {
                    val formatted = RecorderStateBus.formatDuration(seconds)
                    tvTimer.text = formatted
                    tvIslandExpandedTimer.text = formatted

                    val showDynamicIsland =
                        config.dynamicIslandOnRecord && state != RecordingState.IDLE

                    switchToDynamicIslandPosition(root, showDynamicIsland)

                    if (showDynamicIsland) {
                        applyDynamicIslandGeometry(
                            root,
                            resources.configuration.orientation,
                            config
                        )
                        collapsedBubble.visibility = View.GONE
                        expandedPanel.visibility = View.GONE
                        dynamicIslandContainer.visibility = View.VISIBLE
                        islandCompact.visibility = if (isIslandExpanded) View.GONE else View.VISIBLE
                        islandExpanded.visibility = if (isIslandExpanded) View.VISIBLE else View.GONE

                        val micEnabled = config.audioSource == AudioSourceMode.MIC ||
                            config.audioSource == AudioSourceMode.INTERNAL_AND_MIC
                        ivIslandCompactMicOff.visibility =
                            if (micEnabled && micMuted) View.VISIBLE else View.GONE
                        btnIslandMicToggle.isEnabled = micEnabled
                        btnIslandMicToggle.alpha = if (micEnabled) 1.0f else 0.45f
                        btnIslandMicToggle.setImageResource(
                            if (micEnabled && micMuted) R.drawable.ic_mic_off else R.drawable.ic_mic
                        )
                        btnIslandMicToggle.contentDescription = getString(
                            if (micEnabled && micMuted) R.string.action_unmute_mic else R.string.action_mute_mic
                        )

                        val customDotColor = try {
                            Color.parseColor(config.islandDotColorHex)
                        } catch (_: IllegalArgumentException) {
                            Color.parseColor("#F97316")
                        }

                        if (state == RecordingState.PAUSED) {
                            tvIslandStatusLabel.text = getString(R.string.island_paused_title)
                            tvIslandExpandedTimer.setTextColor(Color.parseColor("#F59E0B"))
                            ivIslandRecordRing.setImageResource(R.drawable.bg_dot_paused)
                            ivIslandExpandedRing.setImageResource(R.drawable.bg_dot_paused)
                            updateDotPulseAnimation(ivIslandRecordRing, false)
                            btnIslandPauseResume.setImageResource(R.drawable.ic_resume)
                            btnIslandPauseResume.contentDescription = getString(R.string.action_resume)
                        } else {
                            tvIslandStatusLabel.text = getString(R.string.island_recording_title)
                            tvIslandExpandedTimer.setTextColor(customDotColor)
                            val dotDrawable = createIndicatorDotDrawable(config.islandDotColorHex)
                            ivIslandRecordRing.setImageDrawable(dotDrawable)
                            ivIslandExpandedRing.setImageDrawable(dotDrawable)
                            updateDotPulseAnimation(ivIslandRecordRing, config.dotPulseEnabled)
                            btnIslandPauseResume.setImageResource(R.drawable.ic_pause)
                            btnIslandPauseResume.contentDescription = getString(R.string.action_pause)
                        }
                    } else {
                        ivIslandCompactMicOff.visibility = View.GONE
                        updateDotPulseAnimation(ivIslandRecordRing, false)
                        dynamicIslandContainer.visibility = View.GONE
                        collapsedBubble.visibility = if (isExpanded) View.GONE else View.VISIBLE
                        expandedPanel.visibility = if (isExpanded) View.VISIBLE else View.GONE
                    }

                    when (state) {
                        RecordingState.IDLE -> {
                            btnPrimary.setImageResource(R.drawable.ic_record)
                            btnPrimary.contentDescription = getString(R.string.action_start_recording)
                            btnStop.visibility = View.GONE
                            statusDot.setBackgroundResource(R.drawable.bg_dot_idle)
                            bubbleDot.setBackgroundResource(R.drawable.bg_dot_idle)
                        }

                        RecordingState.RECORDING -> {
                            btnPrimary.setImageResource(R.drawable.ic_pause)
                            btnPrimary.contentDescription = getString(R.string.action_pause)
                            btnStop.visibility = View.VISIBLE
                            statusDot.setBackgroundResource(R.drawable.bg_dot_recording)
                            bubbleDot.setBackgroundResource(R.drawable.bg_dot_recording)
                        }

                        RecordingState.PAUSED -> {
                            btnPrimary.setImageResource(R.drawable.ic_resume)
                            btnPrimary.contentDescription = getString(R.string.action_resume)
                            btnStop.visibility = View.VISIBLE
                            statusDot.setBackgroundResource(R.drawable.bg_dot_paused)
                            bubbleDot.setBackgroundResource(R.drawable.bg_dot_paused)
                        }
                    }
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun getScreenBounds(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = resources.displayMetrics
            metrics.widthPixels to metrics.heightPixels
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_overlay),
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildOverlayNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val hideIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingControlService::class.java).apply { action = ACTION_HIDE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_record)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_desc))
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .addAction(R.drawable.ic_close, getString(R.string.action_hide_widget), hideIntent)
            .build()
    }

    override fun onDestroy() {
        edgeSnapAnimator?.cancel()
        dotPulseAnimator?.cancel()
        floatingView?.let { view ->
            if (view.isAttachedToWindow) {
                try {
                    windowManager.removeView(view)
                } catch (_: Throwable) {
                }
            }
        }
        floatingView = null
        RecorderStateBus.setOverlayVisible(false)
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
