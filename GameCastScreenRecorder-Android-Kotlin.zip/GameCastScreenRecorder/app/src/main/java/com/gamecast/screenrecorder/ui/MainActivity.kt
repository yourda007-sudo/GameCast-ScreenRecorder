package com.gamecast.screenrecorder.ui

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.gamecast.screenrecorder.R
import com.gamecast.screenrecorder.databinding.ActivityMainBinding
import com.gamecast.screenrecorder.media.VideoTrimmer
import com.gamecast.screenrecorder.model.AudioSourceMode
import com.gamecast.screenrecorder.model.RecordedVideo
import com.gamecast.screenrecorder.model.RecorderEvent
import com.gamecast.screenrecorder.model.RecorderStateBus
import com.gamecast.screenrecorder.model.RecordingConfig
import com.gamecast.screenrecorder.model.RecordingState
import com.gamecast.screenrecorder.model.ResolutionPreset
import com.gamecast.screenrecorder.model.VideoCodec
import com.gamecast.screenrecorder.model.VoiceEffectPreset
import com.gamecast.screenrecorder.service.FloatingControlService
import com.gamecast.screenrecorder.service.ScreenRecordService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var recordingsAdapter: RecordingsAdapter

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshPermissionIndicators()
        if (Settings.canDrawOverlays(this)) {
            FloatingControlService.show(this)
        }
    }

    private val runtimePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshPermissionIndicators()
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            ScreenRecordService.startRecording(
                context = this,
                resultCode = result.resultCode,
                data = result.data!!,
                config = RecorderStateBus.config.value
            )
            if (Settings.canDrawOverlays(this)) {
                FloatingControlService.show(this)
            } else if (RecorderStateBus.config.value.dynamicIslandOnRecord) {
                Toast.makeText(
                    this,
                    "Enable 'Display over other apps' permission to show Dynamic Island",
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            Toast.makeText(this, "Screen capture permission declined", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupConfigControls()
        setupActionButtons()
        observeRecorderState()
        requestEssentialRuntimePermissions()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionIndicators()
        loadSavedRecordings()
    }

    private fun setupRecyclerView() {
        recordingsAdapter = RecordingsAdapter(
            onClick = { video ->
                val playIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(video.uriString), "video/mp4")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                if (playIntent.resolveActivity(packageManager) != null) {
                    startActivity(playIntent)
                }
            },
            onTrimClick = { video ->
                trimSavedRecording(video)
            }
        )
        binding.rvRecordings.layoutManager = LinearLayoutManager(this)
        binding.rvRecordings.adapter = recordingsAdapter
    }

    private fun trimSavedRecording(video: RecordedVideo) {
        if (video.durationMs < 2000L) {
            Toast.makeText(this, "Clip is too short to trim", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = arrayOf(
            "0.5x Slow Motion",
            "0.75x Slow",
            "1.0x Normal Trim",
            "1.5x Fast",
            "2.0x Fast Forward"
        )
        val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.5f, 2.0f)

        MaterialAlertDialogBuilder(this)
            .setTitle("Trim & Speed Export")
            .setItems(labels) { _, which ->
                val selectedSpeed = speeds[which]
                val trimEndMs = (video.durationMs * 0.75).toLong().coerceAtLeast(1000L)
                lifecycleScope.launch {
                    try {
                        val (uri, fileName) = VideoTrimmer.trimVideo(
                            context = this@MainActivity,
                            sourceUri = Uri.parse(video.uriString),
                            startMs = 0L,
                            endMs = trimEndMs,
                            speed = selectedSpeed
                        )
                        RecorderStateBus.emitEvent(RecorderEvent.VideoTrimmed(uri, fileName))
                    } catch (t: Throwable) {
                        Toast.makeText(
                            this@MainActivity,
                            "Export failed: ${t.localizedMessage}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupConfigControls() {
        binding.toggleResolution.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val preset = when (checkedId) {
                R.id.btnRes720 -> ResolutionPreset.HD_720P
                R.id.btnResNative -> ResolutionPreset.NATIVE
                else -> ResolutionPreset.FHD_1080P
            }
            updateConfig { it.copy(resolution = preset) }
        }

        binding.toggleFps.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val fps = when (checkedId) {
                R.id.btnFps30 -> 30
                R.id.btnFps90 -> 90
                else -> 60
            }
            updateConfig { it.copy(fps = fps) }
        }

        binding.toggleCodec.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val codec = if (checkedId == R.id.btnCodecHevc) VideoCodec.HEVC else VideoCodec.H264
            updateConfig { it.copy(videoCodec = codec) }
        }

        binding.toggleAudioSource.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val mode = when (checkedId) {
                R.id.btnAudioInternal -> AudioSourceMode.INTERNAL
                R.id.btnAudioMic -> AudioSourceMode.MIC
                R.id.btnAudioMute -> AudioSourceMode.NONE
                else -> AudioSourceMode.INTERNAL_AND_MIC
            }
            if ((mode == AudioSourceMode.MIC || mode == AudioSourceMode.INTERNAL_AND_MIC) &&
                !hasPermission(Manifest.permission.RECORD_AUDIO)
            ) {
                runtimePermissionsLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            }
            updateConfig { it.copy(audioSource = mode) }
        }

        binding.toggleVoiceEffect.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val fx = when (checkedId) {
                R.id.btnFxStudio -> VoiceEffectPreset.STUDIO
                R.id.btnFxDeep -> VoiceEffectPreset.DEEP
                R.id.btnFxPitch -> VoiceEffectPreset.PITCH_BOOST
                else -> VoiceEffectPreset.NORMAL
            }
            updateConfig { it.copy(voiceEffect = fx) }
        }

        binding.switchEdgeSnap.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(edgeSnapEnabled = isChecked) }
        }

        binding.switchDynamicIsland.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(dynamicIslandOnRecord = isChecked) }
        }

        binding.switchDotPulse.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(dotPulseEnabled = isChecked) }
        }

        binding.switchDoubleTapExpand.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(doubleTapToExpand = isChecked) }
        }

        binding.switchLockIsland.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(islandPositionLocked = isChecked) }
        }

        binding.switchShakeStop.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(shakeToStop = isChecked) }
        }

        binding.switchScreenOffStop.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(stopOnScreenOff = isChecked) }
        }

        binding.switchMicNoiseCancel.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(micNoiseCancellation = isChecked) }
        }

        binding.switchAutoDnd.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                val nm = getSystemService(NotificationManager::class.java)
                if (nm != null && !nm.isNotificationPolicyAccessGranted) {
                    Toast.makeText(
                        this,
                        "Grant Do Not Disturb access to silence notifications while recording",
                        Toast.LENGTH_LONG
                    ).show()
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
            }
            updateConfig { it.copy(autoDndOnRecord = isChecked) }
        }

        binding.switchIncludeIslandVideo.setOnCheckedChangeListener { _, isChecked ->
            updateConfig { it.copy(includeIslandInVideo = isChecked) }
        }

        binding.sliderIslandSize.addOnChangeListener { _, value, _ ->
            val pct = (value * 100).toInt()
            binding.tvIslandScaleValue.text = "$pct%"
            updateConfig { it.copy(islandScale = value) }
        }

        binding.sliderIslandOffsetX.addOnChangeListener { _, value, _ ->
            updateConfig { it.copy(islandOffsetX = value.toInt()) }
        }

        binding.sliderIslandOffsetY.addOnChangeListener { _, value, _ ->
            updateConfig { it.copy(islandOffsetY = value.toInt()) }
        }

        setupDotColorSwatches()
    }

    private fun setupDotColorSwatches() {
        val colors = listOf(
            "#F97316",
            "#EF4444",
            "#FACC15",
            "#22C55E",
            "#38BDF8",
            "#A855F7",
            "#FFFFFF"
        )
        val container = binding.dotColorSwatchContainer
        container.removeAllViews()
        val sizePx = (30 * resources.displayMetrics.density).toInt()
        val marginPx = (10 * resources.displayMetrics.density).toInt()

        colors.forEach { hex ->
            val swatch = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                    marginEnd = marginPx
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(hex))
                    setStroke(
                        (2 * resources.displayMetrics.density).toInt(),
                        Color.parseColor("#CBD5E1")
                    )
                }
                contentDescription = "Select indicator dot color $hex"
                setOnClickListener {
                    updateConfig { it.copy(islandDotColorHex = hex) }
                    Toast.makeText(this@MainActivity, "Dot color updated", Toast.LENGTH_SHORT).show()
                }
            }
            container.addView(swatch)
        }
    }

    private fun setupActionButtons() {
        binding.btnGrantOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                overlayPermissionLauncher.launch(intent)
            } else {
                FloatingControlService.show(this)
            }
        }

        binding.btnToggleFloatingWidget.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                overlayPermissionLauncher.launch(intent)
                return@setOnClickListener
            }

            if (RecorderStateBus.overlayVisible.value) {
                FloatingControlService.hide(this)
            } else {
                FloatingControlService.show(this)
            }
        }

        binding.btnStartCapture.setOnClickListener {
            when (RecorderStateBus.state.value) {
                RecordingState.IDLE -> {
                    try {
                        val manager =
                            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        mediaProjectionLauncher.launch(manager.createScreenCaptureIntent())
                    } catch (t: Throwable) {
                        Toast.makeText(
                            this,
                            "Unable to request screen capture: ${t.localizedMessage ?: "Unsupported"}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                RecordingState.RECORDING, RecordingState.PAUSED -> {
                    ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_STOP)
                }
            }
        }
    }

    private fun observeRecorderState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    combine(
                        RecorderStateBus.state,
                        RecorderStateBus.elapsedSeconds,
                        RecorderStateBus.overlayVisible
                    ) { state, seconds, overlayVisible ->
                        Triple(state, seconds, overlayVisible)
                    }.collect { (state, seconds, overlayVisible) ->
                        binding.tvMainTimer.text = RecorderStateBus.formatDuration(seconds)

                        binding.btnStartCapture.text = when (state) {
                            RecordingState.IDLE -> getString(R.string.action_start_recording)
                            RecordingState.RECORDING -> getString(R.string.action_stop_recording)
                            RecordingState.PAUSED -> getString(R.string.action_stop_paused)
                        }

                        binding.btnToggleFloatingWidget.text = if (overlayVisible) {
                            getString(R.string.action_hide_widget)
                        } else {
                            getString(R.string.action_launch_widget)
                        }
                    }
                }

                launch {
                    RecorderStateBus.events.collect { event ->
                        when (event) {
                            is RecorderEvent.RecordingSaved -> {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Saved ${event.fileName}",
                                    Toast.LENGTH_SHORT
                                ).show()
                                loadSavedRecordings()
                            }

                            is RecorderEvent.ScreenshotSaved -> {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Screenshot saved: ${event.fileName}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                            is RecorderEvent.VideoTrimmed -> {
                                Toast.makeText(
                                    this@MainActivity,
                                    "Trimmed clip saved: ${event.fileName}",
                                    Toast.LENGTH_SHORT
                                ).show()
                                loadSavedRecordings()
                            }

                            is RecorderEvent.Error -> {
                                Toast.makeText(
                                    this@MainActivity,
                                    event.message,
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun refreshPermissionIndicators() {
        val overlayGranted = Settings.canDrawOverlays(this)
        binding.tvOverlayStatus.text = if (overlayGranted) "Granted" else "Required"
        binding.btnGrantOverlay.visibility = if (overlayGranted) View.GONE else View.VISIBLE

        val micGranted = hasPermission(Manifest.permission.RECORD_AUDIO)
        binding.tvMicStatus.text = if (micGranted) "Granted" else "Optional"
    }

    private fun requestEssentialRuntimePermissions() {
        val missing = mutableListOf<String>()
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            missing.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        ) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            !hasPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        ) {
            missing.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (missing.isNotEmpty()) {
            runtimePermissionsLauncher.launch(missing.toTypedArray())
        }
    }

    private fun loadSavedRecordings() {
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                queryMediaStoreRecordings()
            }
            recordingsAdapter.submitList(items)
            binding.tvEmptyRecordings.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun queryMediaStoreRecordings(): List<RecordedVideo> {
        val list = mutableListOf<RecordedVideo>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE
        )
        val selection = "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("GameCast_%")
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    list.add(
                        RecordedVideo(
                            id = id,
                            displayName = cursor.getString(nameCol) ?: "Recording.mp4",
                            durationMs = cursor.getLong(durCol),
                            sizeBytes = cursor.getLong(sizeCol),
                            uriString = uri.toString()
                        )
                    )
                }
            }
        } catch (_: Throwable) {
        }
        return list
    }

    private fun updateConfig(transform: (RecordingConfig) -> RecordingConfig) {
        RecorderStateBus.updateConfig(transform(RecorderStateBus.config.value))
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) ==
            PackageManager.PERMISSION_GRANTED
    }
}
