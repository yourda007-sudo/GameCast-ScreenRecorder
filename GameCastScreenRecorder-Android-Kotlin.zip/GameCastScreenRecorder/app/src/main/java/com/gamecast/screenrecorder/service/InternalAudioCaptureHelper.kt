package com.gamecast.screenrecorder.service

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.media.projection.MediaProjection
import android.os.Build
import androidx.annotation.RequiresApi
import com.gamecast.screenrecorder.model.VoiceEffectPreset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

/**
 * Captures internal game/media audio on Android 10+ (API 29+) using AudioPlaybackCaptureConfiguration,
 * optionally applying real-time Voice FX DSP to live microphone PCM samples before mixing.
 */
@RequiresApi(Build.VERSION_CODES.Q)
class InternalAudioCaptureHelper(
    private val mediaProjection: MediaProjection,
    private val includeMic: Boolean,
    private val enableNoiseSuppression: Boolean = true,
    private val voiceEffect: VoiceEffectPreset = VoiceEffectPreset.NORMAL
) {
    companion object {
        private const val SAMPLE_RATE = 44_100
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    private var internalRecord: AudioRecord? = null
    private var micRecord: AudioRecord? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var captureJob: Job? = null

    @Volatile
    private var isPaused = false

    @Volatile
    private var isMicMuted = false

    private var hpPrevIn = 0f
    private var hpPrevOut = 0f
    private var lpPrevOut = 0f

    @SuppressLint("MissingPermission")
    fun startCapture(outputPcmFile: File, scope: CoroutineScope) {
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            .coerceAtLeast(4096)

        val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AUDIO_FORMAT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(CHANNEL_CONFIG)
            .build()

        internalRecord = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(minBuf * 2)
            .setAudioPlaybackCaptureConfig(playbackConfig)
            .build()

        if (includeMic) {
            val mic = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                minBuf * 2
            )
            micRecord = mic

            if (enableNoiseSuppression) {
                val sessionId = mic.audioSessionId
                if (NoiseSuppressor.isAvailable()) {
                    noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply {
                        enabled = true
                    }
                }
                if (AcousticEchoCanceler.isAvailable()) {
                    echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply {
                        enabled = true
                    }
                }
            }
        }

        internalRecord?.startRecording()
        micRecord?.startRecording()

        captureJob = scope.launch(Dispatchers.IO) {
            val gameBuf = ShortArray(minBuf / 2)
            val micBuf = ShortArray(minBuf / 2)
            val outBytes = ByteArray(minBuf)

            FileOutputStream(outputPcmFile).use { fos ->
                while (isActive) {
                    val readGame = internalRecord?.read(gameBuf, 0, gameBuf.size) ?: 0
                    val readMic = if (includeMic) {
                        micRecord?.read(micBuf, 0, micBuf.size) ?: 0
                    } else {
                        0
                    }

                    if (isPaused || readGame <= 0) continue

                    val mixMic = includeMic && !isMicMuted
                    if (mixMic && readMic > 0 && voiceEffect != VoiceEffectPreset.NORMAL) {
                        applyVoiceEffect(micBuf, readMic, voiceEffect)
                    }
                    for (i in 0 until readGame) {
                        val mixed = if (mixMic && i < readMic) {
                            (gameBuf[i].toInt() + micBuf[i].toInt()).coerceIn(
                                Short.MIN_VALUE.toInt(),
                                Short.MAX_VALUE.toInt()
                            )
                        } else {
                            gameBuf[i].toInt()
                        }
                        outBytes[i * 2] = (mixed and 0xFF).toByte()
                        outBytes[i * 2 + 1] = ((mixed shr 8) and 0xFF).toByte()
                    }
                    fos.write(outBytes, 0, readGame * 2)
                }
            }
        }
    }

    private fun applyVoiceEffect(
        micBuf: ShortArray,
        count: Int,
        effect: VoiceEffectPreset
    ) {
        when (effect) {
            VoiceEffectPreset.NORMAL -> Unit
            VoiceEffectPreset.STUDIO -> {
                for (i in 0 until count) {
                    val x = micBuf[i].toFloat()
                    val hp = 0.94f * (hpPrevOut + x - hpPrevIn)
                    hpPrevIn = x
                    hpPrevOut = hp
                    val boosted = (hp * 1.28f).toInt().coerceIn(
                        Short.MIN_VALUE.toInt(),
                        Short.MAX_VALUE.toInt()
                    )
                    micBuf[i] = boosted.toShort()
                }
            }

            VoiceEffectPreset.DEEP, VoiceEffectPreset.PITCH_BOOST -> {
                val ratio = if (effect == VoiceEffectPreset.DEEP) 0.76f else 1.32f
                val copy = micBuf.copyOf(count)
                for (i in 0 until count) {
                    val srcPos = (i * ratio) % count
                    val idx0 = srcPos.toInt().coerceIn(0, count - 1)
                    val idx1 = (idx0 + 1) % count
                    val frac = srcPos - idx0
                    val interp = copy[idx0] * (1f - frac) + copy[idx1] * frac
                    val filtered = if (effect == VoiceEffectPreset.DEEP) {
                        lpPrevOut = lpPrevOut * 0.35f + interp * 0.65f * 1.12f
                        lpPrevOut
                    } else {
                        interp
                    }
                    micBuf[i] = filtered.toInt().coerceIn(
                        Short.MIN_VALUE.toInt(),
                        Short.MAX_VALUE.toInt()
                    ).toShort()
                }
            }
        }
    }

    fun setPaused(paused: Boolean) {
        isPaused = paused
    }

    fun setMicMuted(muted: Boolean) {
        isMicMuted = muted
    }

    fun stopCapture() {
        captureJob?.cancel()
        captureJob = null
        try {
            internalRecord?.stop()
            internalRecord?.release()
        } catch (_: Throwable) {
        } finally {
            internalRecord = null
        }
        try {
            noiseSuppressor?.release()
        } catch (_: Throwable) {
        } finally {
            noiseSuppressor = null
        }
        try {
            echoCanceler?.release()
        } catch (_: Throwable) {
        } finally {
            echoCanceler = null
        }
        try {
            micRecord?.stop()
            micRecord?.release()
        } catch (_: Throwable) {
        } finally {
            micRecord = null
        }
    }
}
