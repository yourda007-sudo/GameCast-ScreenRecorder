package com.gamecast.screenrecorder.service

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioManager
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.gamecast.screenrecorder.R
import com.gamecast.screenrecorder.model.AudioSourceMode
import com.gamecast.screenrecorder.model.RecorderEvent
import com.gamecast.screenrecorder.model.RecorderStateBus
import com.gamecast.screenrecorder.model.RecordingConfig
import com.gamecast.screenrecorder.model.RecordingState
import com.gamecast.screenrecorder.model.ResolutionPreset
import com.gamecast.screenrecorder.model.VideoCodec
import com.gamecast.screenrecorder.ui.MainActivity
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

class ScreenRecordService : Service(), SensorEventListener {

    companion object {
        const val ACTION_START = "com.gamecast.screenrecorder.action.START"
        const val ACTION_PAUSE = "com.gamecast.screenrecorder.action.PAUSE"
        const val ACTION_RESUME = "com.gamecast.screenrecorder.action.RESUME"
        const val ACTION_STOP = "com.gamecast.screenrecorder.action.STOP"
        const val ACTION_SCREENSHOT = "com.gamecast.screenrecorder.action.SCREENSHOT"
        const val ACTION_TOGGLE_MIC = "com.gamecast.screenrecorder.action.TOGGLE_MIC"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_CONFIG = "extra_config"

        private const val CHANNEL_ID = "gamecast_recording_channel"
        private const val NOTIFICATION_ID = 1002
        private const val SHAKE_THRESHOLD_G = 2.7f

        fun startRecording(
            context: Context,
            resultCode: Int,
            data: Intent,
            config: RecordingConfig
        ) {
            try {
                val intent = Intent(context, ScreenRecordService::class.java).apply {
                    action = ACTION_START
                    putExtra(EXTRA_RESULT_CODE, resultCode)
                    putExtra(EXTRA_RESULT_DATA, data)
                    putExtra(EXTRA_CONFIG, config)
                }
                ContextCompat.startForegroundService(context, intent)
            } catch (t: Throwable) {
                RecorderStateBus.emitEvent(
                    RecorderEvent.Error("Unable to start recorder service: ${t.localizedMessage ?: "Blocked"}")
                )
            }
        }

        fun sendAction(context: Context, action: String) {
            try {
                val intent = Intent(context, ScreenRecordService::class.java).apply {
                    this.action = action
                }
                context.startService(intent)
            } catch (_: Throwable) {
            }
        }
    }

    private val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        showMainToast("Recorder error: ${throwable.localizedMessage ?: "Unknown"}")
    }
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main + exceptionHandler)
    private var timerJob: Job? = null

    private var mediaProjectionManager: MediaProjectionManager? = null
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var internalAudioHelper: InternalAudioCaptureHelper? = null
    private var internalAudioPcmFile: File? = null

    private var outputPfd: ParcelFileDescriptor? = null
    private var outputUri: Uri? = null
    private var outputFileName: String = ""

    private var activeConfig = RecordingConfig()
    private var elapsedSeconds = 0L
    private var captureWidth = 1080
    private var captureHeight = 1920
    private var captureDpi = 420

    private var sensorManager: SensorManager? = null
    private var lastShakeTimestamp = 0L
    private var screenOffReceiverRegistered = false
    private var previousDndFilter: Int? = null
    private var previousMicMuteState: Boolean? = null

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF &&
                activeConfig.stopOnScreenOff &&
                RecorderStateBus.state.value != RecordingState.IDLE
            ) {
                stopRecordingAndCleanup()
            }
        }
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopRecordingAndCleanup()
        }
    }

    override fun onCreate() {
        super.onCreate()
        mediaProjectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (RecorderStateBus.state.value != RecordingState.IDLE) {
                    return START_NOT_STICKY
                }
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                val config = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_CONFIG, RecordingConfig::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_CONFIG)
                } ?: RecorderStateBus.config.value

                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    RecorderStateBus.emitEvent(
                        RecorderEvent.Error("Screen capture permission was not granted.")
                    )
                    stopSelf()
                    return START_NOT_STICKY
                }

                activeConfig = config
                beginForegroundAndCapture(resultCode, resultData)
            }

            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP -> stopRecordingAndCleanup()
            ACTION_SCREENSHOT -> captureInstantScreenshot()
            ACTION_TOGGLE_MIC -> toggleMicMute()
        }
        return START_NOT_STICKY
    }

    private fun hasMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun showMainToast(message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun beginForegroundAndCapture(resultCode: Int, resultData: Intent) {
        try {
            val notification = buildNotification(RecordingState.RECORDING, 0L)
            val micGranted = hasMicPermission()
            val wantsMic = activeConfig.audioSource == AudioSourceMode.MIC ||
                activeConfig.audioSource == AudioSourceMode.INTERNAL_AND_MIC

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val fgsType = if (micGranted && wantsMic) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                }
                startForeground(NOTIFICATION_ID, notification, fgsType)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            val projection = mediaProjectionManager?.getMediaProjection(resultCode, resultData)
                ?: throw IllegalStateException("MediaProjection instance is null.")
            mediaProjection = projection
            projection.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))

            val (width, height, densityDpi) = resolveCaptureMetrics(activeConfig.resolution)
            captureWidth = width
            captureHeight = height
            captureDpi = densityDpi

            prepareMediaRecorder(width, height, micGranted)

            virtualDisplay = projection.createVirtualDisplay(
                "GameCastVirtualDisplay",
                width,
                height,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mediaRecorder?.surface,
                null,
                Handler(Looper.getMainLooper())
            )

            mediaRecorder?.start()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                (activeConfig.audioSource == AudioSourceMode.INTERNAL ||
                    activeConfig.audioSource == AudioSourceMode.INTERNAL_AND_MIC)
            ) {
                try {
                    val pcmOut = File(cacheDir, "internal_audio_${System.currentTimeMillis()}.pcm")
                    internalAudioPcmFile = pcmOut
                    internalAudioHelper = InternalAudioCaptureHelper(
                        mediaProjection = projection,
                        includeMic = micGranted && activeConfig.audioSource == AudioSourceMode.INTERNAL_AND_MIC,
                        enableNoiseSuppression = activeConfig.micNoiseCancellation,
                        voiceEffect = activeConfig.voiceEffect
                    ).also { helper ->
                        helper.startCapture(pcmOut, serviceScope)
                    }
                } catch (_: Throwable) {
                    // Continue video recording cleanly even if internal audio playback capture is restricted
                    internalAudioHelper = null
                }
            }

            registerSafetyTriggers()
            enableAutoDndIfGranted()

            elapsedSeconds = 0L
            RecorderStateBus.setMicMuted(false)
            RecorderStateBus.updateElapsedSeconds(0L)
            RecorderStateBus.updateState(RecordingState.RECORDING)
            startTimerLoop()
        } catch (t: Throwable) {
            val errMsg = "Failed to start recording: ${t.localizedMessage ?: "Unknown error"}"
            RecorderStateBus.emitEvent(RecorderEvent.Error(errMsg))
            showMainToast(errMsg)
            releaseResources(saveFile = false)
            stopSelf()
        }
    }

    private fun prepareMediaRecorder(width: Int, height: Int, micGranted: Boolean) {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        outputFileName = "GameCast_$timestamp.mp4"

        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(this)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        val useMicInMediaRecorder =
            micGranted && activeConfig.audioSource == AudioSourceMode.MIC
        if (useMicInMediaRecorder) {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
        }
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)

        val descriptor = createOutputDescriptor(outputFileName)
        outputPfd = descriptor
        recorder.setOutputFile(descriptor.fileDescriptor)

        val encoder = when (activeConfig.videoCodec) {
            VideoCodec.HEVC -> MediaRecorder.VideoEncoder.HEVC
            VideoCodec.H264 -> MediaRecorder.VideoEncoder.H264
        }
        recorder.setVideoEncoder(encoder)

        if (useMicInMediaRecorder) {
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioEncodingBitRate(128_000)
            recorder.setAudioSamplingRate(44_100)
        }

        recorder.setVideoSize(width, height)
        recorder.setVideoFrameRate(activeConfig.fps)
        recorder.setVideoEncodingBitRate(activeConfig.bitrateMbps * 1_000_000)
        recorder.prepare()

        mediaRecorder = recorder
    }

    private fun captureInstantScreenshot() {
        val projection = mediaProjection ?: return
        val reader = ImageReader.newInstance(
            captureWidth,
            captureHeight,
            PixelFormat.RGBA_8888,
            2
        )
        var shotDisplay: VirtualDisplay? = null

        shotDisplay = projection.createVirtualDisplay(
            "GameCastScreenshot",
            captureWidth,
            captureHeight,
            captureDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            Handler(Looper.getMainLooper())
        )

        reader.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * captureWidth
                val bitmap = Bitmap.createBitmap(
                    captureWidth + rowPadding / pixelStride,
                    captureHeight,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(bitmap, 0, 0, captureWidth, captureHeight)
                if (cropped != bitmap) bitmap.recycle()

                serviceScope.launch(Dispatchers.IO) {
                    saveScreenshotBitmap(cropped)
                    cropped.recycle()
                }
            } finally {
                image.close()
                r.setOnImageAvailableListener(null, null)
                shotDisplay?.release()
                r.close()
            }
        }, Handler(Looper.getMainLooper()))
    }

    private fun saveScreenshotBitmap(bitmap: Bitmap) {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "GameCast_Shot_$timestamp.png"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_PICTURES}/GameCast Screenshots"
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return
            contentResolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            RecorderStateBus.emitEvent(RecorderEvent.ScreenshotSaved(uri, fileName))
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "GameCast Screenshots"
            ).apply { mkdirs() }
            val file = File(dir, fileName)
            file.outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            RecorderStateBus.emitEvent(RecorderEvent.ScreenshotSaved(Uri.fromFile(file), fileName))
        }
    }

    private fun registerSafetyTriggers() {
        if (activeConfig.shakeToStop) {
            val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (accelerometer != null) {
                sensorManager?.registerListener(
                    this,
                    accelerometer,
                    SensorManager.SENSOR_DELAY_UI
                )
            }
        }
        if (activeConfig.stopOnScreenOff && !screenOffReceiverRegistered) {
            ContextCompat.registerReceiver(
                this,
                screenOffReceiver,
                IntentFilter(Intent.ACTION_SCREEN_OFF),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            screenOffReceiverRegistered = true
        }
    }

    private fun unregisterSafetyTriggers() {
        sensorManager?.unregisterListener(this)
        if (screenOffReceiverRegistered) {
            try {
                unregisterReceiver(screenOffReceiver)
            } catch (_: IllegalArgumentException) {
            }
            screenOffReceiverRegistered = false
        }
        restoreDndIfNeeded()
    }

    private fun enableAutoDndIfGranted() {
        if (!activeConfig.autoDndOnRecord) return
        val nm = getSystemService(NotificationManager::class.java) ?: return
        if (!nm.isNotificationPolicyAccessGranted) return
        try {
            if (previousDndFilter == null) {
                previousDndFilter = nm.currentInterruptionFilter
            }
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } catch (_: SecurityException) {
        }
    }

    private fun restoreDndIfNeeded() {
        val prev = previousDndFilter ?: return
        previousDndFilter = null
        val nm = getSystemService(NotificationManager::class.java) ?: return
        if (!nm.isNotificationPolicyAccessGranted) return
        try {
            nm.setInterruptionFilter(prev)
        } catch (_: SecurityException) {
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (!activeConfig.shakeToStop || event?.sensor?.type != Sensor.TYPE_ACCELEROMETER) return
        val gX = event.values[0] / SensorManager.GRAVITY_EARTH
        val gY = event.values[1] / SensorManager.GRAVITY_EARTH
        val gZ = event.values[2] / SensorManager.GRAVITY_EARTH
        val gForce = sqrt(gX * gX + gY * gY + gZ * gZ)

        if (gForce > SHAKE_THRESHOLD_G) {
            val now = System.currentTimeMillis()
            if (now - lastShakeTimestamp > 1200L) {
                lastShakeTimestamp = now
                stopRecordingAndCleanup()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun createOutputDescriptor(fileName: String): ParcelFileDescriptor {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_MOVIES}/GameCast Recorder"
                )
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Unable to create MediaStore video entry.")
            outputUri = uri
            return contentResolver.openFileDescriptor(uri, "w")
                ?: throw IllegalStateException("Unable to open ParcelFileDescriptor.")
        } else {
            @Suppress("DEPRECATION")
            val moviesDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "GameCast Recorder"
            ).apply { mkdirs() }
            val file = File(moviesDir, fileName)
            outputUri = Uri.fromFile(file)
            return ParcelFileDescriptor.open(
                file,
                ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_READ_WRITE
            )
        }
    }

    private fun resolveCaptureMetrics(preset: ResolutionPreset): Triple<Int, Int, Int> {
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val rawWidth: Int
        val rawHeight: Int
        val densityDpi: Int

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            rawWidth = bounds.width()
            rawHeight = bounds.height()
            densityDpi = resources.configuration.densityDpi
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            rawWidth = metrics.widthPixels
            rawHeight = metrics.heightPixels
            densityDpi = metrics.densityDpi
        }

        if (preset == ResolutionPreset.NATIVE) {
            return Triple(alignEven(rawWidth), alignEven(rawHeight), densityDpi)
        }

        val shortEdge = minOf(rawWidth, rawHeight)
        val scale = if (shortEdge > preset.targetShortEdge) {
            preset.targetShortEdge.toFloat() / shortEdge.toFloat()
        } else {
            1f
        }

        val scaledWidth = alignEven((rawWidth * scale).toInt())
        val scaledHeight = alignEven((rawHeight * scale).toInt())
        return Triple(scaledWidth, scaledHeight, densityDpi)
    }

    private fun alignEven(value: Int): Int = (value / 2) * 2

    private fun toggleMicMute() {
        val state = RecorderStateBus.state.value
        if (state == RecordingState.IDLE) return
        if (activeConfig.audioSource != AudioSourceMode.MIC &&
            activeConfig.audioSource != AudioSourceMode.INTERNAL_AND_MIC
        ) {
            return
        }
        val muted = RecorderStateBus.toggleMicMuted()
        internalAudioHelper?.setMicMuted(muted)
        if (activeConfig.audioSource == AudioSourceMode.MIC) {
            val am = getSystemService(AudioManager::class.java)
            if (am != null) {
                if (previousMicMuteState == null) {
                    previousMicMuteState = am.isMicrophoneMute
                }
                @Suppress("DEPRECATION")
                am.isMicrophoneMute = muted
            }
        }
    }

    private fun pauseRecording() {
        if (RecorderStateBus.state.value != RecordingState.RECORDING) return
        try {
            mediaRecorder?.pause()
            internalAudioHelper?.setPaused(true)
            RecorderStateBus.updateState(RecordingState.PAUSED)
            updateNotification(RecordingState.PAUSED, elapsedSeconds)
        } catch (t: Throwable) {
            RecorderStateBus.emitEvent(
                RecorderEvent.Error("Unable to pause recording: ${t.localizedMessage}")
            )
        }
    }

    private fun resumeRecording() {
        if (RecorderStateBus.state.value != RecordingState.PAUSED) return
        try {
            mediaRecorder?.resume()
            internalAudioHelper?.setPaused(false)
            RecorderStateBus.updateState(RecordingState.RECORDING)
            updateNotification(RecordingState.RECORDING, elapsedSeconds)
        } catch (t: Throwable) {
            RecorderStateBus.emitEvent(
                RecorderEvent.Error("Unable to resume recording: ${t.localizedMessage}")
            )
        }
    }

    private fun stopRecordingAndCleanup() {
        timerJob?.cancel()
        timerJob = null
        unregisterSafetyTriggers()

        val hadRecording = RecorderStateBus.state.value != RecordingState.IDLE
        releaseResources(saveFile = hadRecording)

        RecorderStateBus.updateState(RecordingState.IDLE)
        RecorderStateBus.updateElapsedSeconds(0L)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun releaseResources(saveFile: Boolean) {
        try {
            internalAudioHelper?.stopCapture()
        } catch (_: Throwable) {
        } finally {
            internalAudioHelper = null
        }

        previousMicMuteState?.let { prev ->
            previousMicMuteState = null
            try {
                val am = getSystemService(AudioManager::class.java)
                @Suppress("DEPRECATION")
                am?.isMicrophoneMute = prev
            } catch (_: Throwable) {
            }
        }
        RecorderStateBus.setMicMuted(false)

        internalAudioPcmFile?.delete()
        internalAudioPcmFile = null

        try {
            mediaRecorder?.apply {
                try {
                    stop()
                } catch (_: RuntimeException) {
                }
                reset()
                release()
            }
        } catch (_: Throwable) {
        } finally {
            mediaRecorder = null
        }

        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {
        } finally {
            virtualDisplay = null
        }

        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (_: Throwable) {
        } finally {
            mediaProjection = null
        }

        try {
            outputPfd?.close()
        } catch (_: Throwable) {
        } finally {
            outputPfd = null
        }

        val uri = outputUri
        if (uri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (saveFile) {
                val finalized = ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }
                contentResolver.update(uri, finalized, null, null)
                RecorderStateBus.emitEvent(RecorderEvent.RecordingSaved(uri, outputFileName))
            } else {
                contentResolver.delete(uri, null, null)
            }
        } else if (uri != null && saveFile) {
            RecorderStateBus.emitEvent(RecorderEvent.RecordingSaved(uri, outputFileName))
        }
        outputUri = null
    }

    private fun startTimerLoop() {
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive) {
                delay(1000L)
                if (RecorderStateBus.state.value == RecordingState.RECORDING) {
                    elapsedSeconds += 1L
                    RecorderStateBus.updateElapsedSeconds(elapsedSeconds)
                    updateNotification(RecordingState.RECORDING, elapsedSeconds)
                }
            }
        }
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_recording),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_recording_desc)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun updateNotification(state: RecordingState, seconds: Long) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(state, seconds))
    }

    private fun buildNotification(state: RecordingState, seconds: Long): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ScreenRecordService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleAction = if (state == RecordingState.PAUSED) {
            val resumeIntent = PendingIntent.getService(
                this,
                2,
                Intent(this, ScreenRecordService::class.java).apply { action = ACTION_RESUME },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            NotificationCompat.Action(
                R.drawable.ic_resume,
                getString(R.string.action_resume),
                resumeIntent
            )
        } else {
            val pauseIntent = PendingIntent.getService(
                this,
                2,
                Intent(this, ScreenRecordService::class.java).apply { action = ACTION_PAUSE },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            NotificationCompat.Action(
                R.drawable.ic_pause,
                getString(R.string.action_pause),
                pauseIntent
            )
        }

        val statusTitle = if (state == RecordingState.PAUSED) {
            "Recording Paused · ${RecorderStateBus.formatDuration(seconds)}"
        } else {
            "Recording Screen · ${RecorderStateBus.formatDuration(seconds)}"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_record)
            .setContentTitle(statusTitle)
            .setContentText("${activeConfig.resolution.label} · ${activeConfig.fps} fps · ${activeConfig.videoCodec.name}")
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(toggleAction)
            .addAction(R.drawable.ic_stop, getString(R.string.action_stop), stopIntent)
            .build()
    }

    override fun onDestroy() {
        timerJob?.cancel()
        unregisterSafetyTriggers()
        releaseResources(saveFile = false)
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
