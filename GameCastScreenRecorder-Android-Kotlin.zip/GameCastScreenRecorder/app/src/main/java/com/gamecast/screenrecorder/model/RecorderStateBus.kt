package com.gamecast.screenrecorder.model

import android.net.Uri
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

enum class RecordingState {
    IDLE,
    RECORDING,
    PAUSED
}

sealed interface RecorderEvent {
    data class RecordingSaved(val uri: Uri, val fileName: String) : RecorderEvent
    data class ScreenshotSaved(val uri: Uri, val fileName: String) : RecorderEvent
    data class VideoTrimmed(val uri: Uri, val fileName: String) : RecorderEvent
    data class Error(val message: String) : RecorderEvent
}

object RecorderStateBus {
    private val _state = MutableStateFlow(RecordingState.IDLE)
    val state: StateFlow<RecordingState> = _state.asStateFlow()

    private val _elapsedSeconds = MutableStateFlow(0L)
    val elapsedSeconds: StateFlow<Long> = _elapsedSeconds.asStateFlow()

    private val _overlayVisible = MutableStateFlow(false)
    val overlayVisible: StateFlow<Boolean> = _overlayVisible.asStateFlow()

    private val _config = MutableStateFlow(RecordingConfig())
    val config: StateFlow<RecordingConfig> = _config.asStateFlow()

    private val _micMuted = MutableStateFlow(false)
    val micMuted: StateFlow<Boolean> = _micMuted.asStateFlow()

    private val _events = MutableSharedFlow<RecorderEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<RecorderEvent> = _events.asSharedFlow()

    fun updateState(newState: RecordingState) {
        _state.value = newState
    }

    fun updateElapsedSeconds(seconds: Long) {
        _elapsedSeconds.value = seconds
    }

    fun setOverlayVisible(visible: Boolean) {
        _overlayVisible.value = visible
    }

    fun updateConfig(newConfig: RecordingConfig) {
        _config.value = newConfig
    }

    fun setMicMuted(muted: Boolean) {
        _micMuted.value = muted
    }

    fun toggleMicMuted(): Boolean {
        val next = !_micMuted.value
        _micMuted.value = next
        return next
    }

    fun emitEvent(event: RecorderEvent) {
        _events.tryEmit(event)
    }

    fun formatDuration(totalSeconds: Long): String {
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }
}
