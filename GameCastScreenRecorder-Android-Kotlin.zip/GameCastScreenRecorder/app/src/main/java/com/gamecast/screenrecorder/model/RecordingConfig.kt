package com.gamecast.screenrecorder.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

enum class ResolutionPreset(val label: String, val targetShortEdge: Int) {
    HD_720P("720p HD", 720),
    FHD_1080P("1080p Full HD", 1080),
    NATIVE("Native Display", 0)
}

enum class AudioSourceMode(val label: String) {
    INTERNAL("Game Internal Audio"),
    MIC("Microphone"),
    INTERNAL_AND_MIC("Internal + Mic"),
    NONE("Muted")
}

enum class VideoCodec(val label: String) {
    H264("H.264 (AVC)"),
    HEVC("H.265 (HEVC)")
}

enum class VoiceEffectPreset(val label: String) {
    NORMAL("Normal"),
    STUDIO("Studio Crisp"),
    DEEP("Deep Gaming"),
    PITCH_BOOST("Pitch Boost")
}

@Parcelize
data class RecordingConfig(
    val resolution: ResolutionPreset = ResolutionPreset.FHD_1080P,
    val fps: Int = 60,
    val bitrateMbps: Int = 12,
    val videoCodec: VideoCodec = VideoCodec.H264,
    val audioSource: AudioSourceMode = AudioSourceMode.INTERNAL_AND_MIC,
    val voiceEffect: VoiceEffectPreset = VoiceEffectPreset.NORMAL,
    val edgeSnapEnabled: Boolean = true,
    val dynamicIslandOnRecord: Boolean = true,
    val islandScale: Float = 1.0f,
    val islandOffsetX: Int = 0,
    val islandOffsetY: Int = 0,
    val islandPositionLocked: Boolean = false,
    val islandCornerRadiusDp: Int = 28,
    val islandOpacity: Float = 1.0f,
    val islandDotColorHex: String = "#F97316",
    val dotScale: Float = 1.0f,
    val dotPulseEnabled: Boolean = true,
    val doubleTapToExpand: Boolean = false,
    val shakeToStop: Boolean = false,
    val stopOnScreenOff: Boolean = true,
    val micNoiseCancellation: Boolean = true,
    val autoDndOnRecord: Boolean = false,
    val includeIslandInVideo: Boolean = true
) : Parcelable {
    val recordAudio: Boolean
        get() = audioSource != AudioSourceMode.NONE
}

data class RecordedVideo(
    val id: Long,
    val displayName: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val uriString: String
)
