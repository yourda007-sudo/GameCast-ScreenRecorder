package com.gamecast.screenrecorder.ui

import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.gamecast.screenrecorder.model.RecorderEvent
import com.gamecast.screenrecorder.model.RecorderStateBus
import com.gamecast.screenrecorder.service.ScreenRecordService

/**
 * Invisible single-instance trampoline Activity launched by FloatingControlService
 * so the user can authorize MediaProjection directly over any foreground game or app.
 */
class ProjectionPromptActivity : AppCompatActivity() {

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            ScreenRecordService.startRecording(
                context = applicationContext,
                resultCode = result.resultCode,
                data = result.data!!,
                config = RecorderStateBus.config.value
            )
        } else {
            RecorderStateBus.emitEvent(
                RecorderEvent.Error("Screen capture permission declined.")
            )
        }
        finish()
        overridePendingTransition(0, 0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }
}
