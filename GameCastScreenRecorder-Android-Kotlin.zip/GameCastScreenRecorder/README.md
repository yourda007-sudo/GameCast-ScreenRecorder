# GameCast Android Screen Recorder

Complete Kotlin Android application (`minSdk = 26`, `targetSdk = 35`) implementing a game-recorder style floating control overlay (`SYSTEM_ALERT_WINDOW`) paired with smooth `MediaProjection` + `VirtualDisplay` + `MediaRecorder` screen capture.

## Key Capabilities

1. **Draggable Floating Control Widget (`FloatingControlService.kt`)**
   - Uses `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY` with `FLAG_NOT_FOCUSABLE` so touches pass through to underlying games/apps.
   - Smooth drag-and-drop movement (`ACTION_DOWN`, `ACTION_MOVE`, `ACTION_UP`) with `scaledTouchSlop` tap-vs-drag detection and optional edge-snap `ValueAnimator`.
   - Expands/collapses between a compact floating bubble and a full control capsule with **Record / Pause / Resume**, **Stop**, **Timer**, and **Close** actions.

2. **MediaProjection Capture Pipeline (`ScreenRecordService.kt`)**
   - Starts `foregroundServiceType="mediaProjection"` **before** calling `MediaProjectionManager.getMediaProjection()` (required on Android 14+ / API 34+).
   - Registers `MediaProjection.Callback` to handle system capture revocation cleanly.
   - Supports `MediaRecorder.pause()` and `MediaRecorder.resume()` without splitting output files.
   - Writes H.264/AAC MP4 files directly to `MediaStore.Video.Media` (`Movies/GameCast Recorder`) with `IS_PENDING` scoped storage support.

3. **Seamless In-Game Projection Prompt (`ProjectionPromptActivity.kt`)**
   - When tapping **Record** from the floating bubble while inside another app or game, launches a zero-animation transparent Activity to present the Android `MediaProjection` consent sheet without pulling the user out of their game.

## Opening in Android Studio

1. Open the `android-app` folder in Android Studio (Ladybug / Meerkat or newer).
2. Let Gradle sync (`compileSdk = 35`, Kotlin `2.0.21`).
3. Run on a physical Android device or emulator (API 26–35).
4. Grant **Display over other apps** (`SYSTEM_ALERT_WINDOW`) and launch the floating widget.
